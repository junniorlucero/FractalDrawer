Junnior Lucero, lucer045

How to compile and run program:
Ensure you are running the latest version of Java and that all of your files for this project are within the same directory. This includes
Circle.java, Triangle.java, Rectangle.java, FractalDrawer.java, and Canvas.java. Simply click run on your favorite IDE and input one of 
the following shapes - circle, triangle, or rectangle (not case sensitive). Your shape will be drawn on a separate window, make sure to
click fullscreen on that window to fully visualize your fractal drawing.

Assumptions:
We assume that the user inputs a valid shape, either circle, triangle, or rectangle.

Additional Features:
None

Bugs or defects:
None

I certify that the information contained in this README file is complete an accurate. I have both read and followed
the course policies in the 'Academic Integrity - Course Policy' section of the course syllabus.
Junnior Lucero  
